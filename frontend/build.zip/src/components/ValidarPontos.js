import React, { useEffect, useState, useContext, useCallback, useRef } from 'react';
import { writeBatch, Timestamp } from "firebase/firestore";
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { collection, getDocs, addDoc, query, orderBy, limit, startAfter, doc } from 'firebase/firestore';
import { db } from '../config/firebase';
import { AuthContext } from '../context/AuthContext';
import {
    FiMenu, FiUser, FiFileText, FiClock, FiCheck, FiX,
    FiHome, FiUsers, FiLogOut, FiRefreshCw, FiChevronRight
} from 'react-icons/fi';
import './ValidarPontos.css';

const permissoesMap = {
    1: "Gestor",
    2: "Gerente Geral",
    3: "Gerente de Equipes",
    4: "Frentista",
};

// Função universal para formatar datas
const formatarData = (data) => {
    if (!data) return "-";

    let dateObj;

    if (data instanceof Timestamp) {
        dateObj = data.toDate();
    } else if (typeof data === 'string') {
        dateObj = new Date(data);
    } else if (data instanceof Date) {
        dateObj = data;
    } else {
        return "-";
    }

    return dateObj.toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
};

const ValidarPontos = () => {
    const location = useLocation();
    const navigate = useNavigate();

    // Layout
    const [sidebarOpen, setSidebarOpen] = useState(true);
    const [submenuOpen, setSubmenuOpen] = useState({ usuarios: false, relatorios: false });

    // Dados
    const [pontos, setPontos] = useState([]);
    const [usuarios, setUsuarios] = useState([]);
    const [dataLoading, setDataLoading] = useState(false);
    const [initialLoad, setInitialLoad] = useState(true);
    const [lastDoc, setLastDoc] = useState(null);
    const [hasMore, setHasMore] = useState(true);
    const [isRefreshing, setIsRefreshing] = useState(false);

    // Modais
    const [selectedPonto, setSelectedPonto] = useState(null);
    const [showRegistroModal, setShowRegistroModal] = useState(false);
    const [registroType, setRegistroType] = useState("");
    const [idLoginFalta, setIdLoginFalta] = useState("");
    const [justificativa, setJustificativa] = useState("");

    // Loading individual
    const [loadingPontos, setLoadingPontos] = useState({});

    // Refs
    const loadMoreRef = useRef(null);
    const observerRef = useRef(null);
    const sidebarRef = useRef(null);

    const { user: usuarioLogado, isAuthenticated, logout } = useContext(AuthContext);

    const setLoadingForPonto = (id, value) => setLoadingPontos(prev => ({ ...prev, [id]: value }));

    // Listar pontos
    const listarPontosFirestore = useCallback(async (lastDocument = null) => {
        try {
            let q = query(collection(db, "pontos"), orderBy("horaPonto", "desc"), limit(10));
            if (lastDocument) q = query(q, startAfter(lastDocument));

            const querySnapshot = await getDocs(q);
            const listaPontos = querySnapshot.docs
                .map(doc => ({ id: doc.id, ...doc.data() }))
                .filter(ponto => !ponto.status);

            setLastDoc(querySnapshot.docs[querySnapshot.docs.length - 1]);
            setHasMore(querySnapshot.docs.length === 10);

            return listaPontos;
        } catch (error) {
            console.error("Erro ao buscar pontos:", error);
            throw error;
        }
    }, []);

    // Listar usuários
    const listarUsuariosFirestore = useCallback(async () => {
        const querySnapshot = await getDocs(collection(db, "users"));
        return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    }, []);

    const loadInitialData = useCallback(async () => {
        if (!isAuthenticated) return;
        setDataLoading(true);
        try {
            const [usuariosData, pontosData] = await Promise.all([listarUsuariosFirestore(), listarPontosFirestore()]);
            setUsuarios(usuariosData);
            setPontos(pontosData);
        } catch (error) {
            console.error("Erro ao carregar dados:", error);
        } finally {
            setDataLoading(false);
            setInitialLoad(false);
        }
    }, [isAuthenticated, listarUsuariosFirestore, listarPontosFirestore]);

    const loadMoreData = useCallback(async () => {
        if (!hasMore || dataLoading) return;
        setDataLoading(true);
        try {
            const newPontos = await listarPontosFirestore(lastDoc);
            setPontos(prev => [...prev, ...newPontos]);
        } catch (error) {
            console.error("Erro ao carregar mais pontos:", error);
        } finally {
            setDataLoading(false);
        }
    }, [hasMore, dataLoading, lastDoc, listarPontosFirestore]);

    const refreshData = useCallback(async () => {
        setIsRefreshing(true);
        try {
            const [usuariosData, pontosData] = await Promise.all([listarUsuariosFirestore(), listarPontosFirestore()]);
            setUsuarios(usuariosData);
            setPontos(pontosData);
            setLastDoc(null);
            setHasMore(true);
        } catch (error) {
            console.error("Erro ao atualizar dados:", error);
        } finally {
            setIsRefreshing(false);
        }
    }, [listarUsuariosFirestore, listarPontosFirestore]);

    useEffect(() => {
        if (!loadMoreRef.current || !hasMore) return;
        const observer = new IntersectionObserver(entries => {
            if (entries[0].isIntersecting) loadMoreData();
        }, { threshold: 0.1 });
        observer.observe(loadMoreRef.current);
        observerRef.current = observer;
        return () => observerRef.current?.disconnect();
    }, [hasMore, loadMoreData]);

    useEffect(() => { if (isAuthenticated && initialLoad) loadInitialData(); }, [isAuthenticated, initialLoad, loadInitialData]);

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (sidebarRef.current && !sidebarRef.current.contains(event.target) &&
                !event.target.closest('.toggle-btn') && window.innerWidth <= 768) {
                setSidebarOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const getUsuarioByIdLogin = useCallback((idLogin) => {
        const usuario = usuarios.find(user => user.idLogin === idLogin);
        return usuario ? usuario : { name: 'Desconhecido', role: 'Desconhecido', permissao: 0 };
    }, [usuarios]);

    const temPermissaoParaVer = useCallback((cargoPonto) => {
        const cargoUsuarioLogado = usuarioLogado?.permissao || 0;
        if (cargoUsuarioLogado === 1) return true;
        if (cargoUsuarioLogado === 2) return cargoPonto === 3 || cargoPonto === 4;
        if (cargoUsuarioLogado === 3) return cargoPonto === 4;
        if (cargoUsuarioLogado < cargoPonto) return true;
        return false;
    }, [usuarioLogado]);

    const temPermissaoParaRegistrar = useCallback((cargoAlvo) => {
        const cargoUsuarioLogado = usuarioLogado?.permissao || 0;
        if (cargoUsuarioLogado === 1) return true;
        if (cargoUsuarioLogado === 2) return cargoAlvo === 3 || cargoAlvo === 4;
        if (cargoUsuarioLogado === 3) return cargoAlvo === 4;
        if (cargoUsuarioLogado < cargoAlvo) return true;
        return false;
    }, [usuarioLogado]);

    // Abrir modal de registro
    const abrirRegistro = (tipo) => {
        setRegistroType(tipo);
        setShowRegistroModal(true);
        setIdLoginFalta("");
        setJustificativa("");
    };

    // Aprovar ponto
    const handleAprovar = async (ponto) => {
        setLoadingForPonto(ponto.id, true);
        try {
            const currentUser = usuarioLogado?.name || "Administrador";
            const batch = writeBatch(db);
            const pontoRef = doc(db, "pontos", ponto.id);
            batch.update(pontoRef, { status: "Aprovado", aprovadoPor: currentUser, dataAprovacao: new Date().toISOString() });
            const pontosEfetivadosRef = collection(db, "pontosEfetivados");
            batch.set(doc(pontosEfetivadosRef), {
                pontoId: ponto.id,
                status: "Aprovado",
                usuario: ponto.usuario || "Desconhecido",
                idLogin: ponto.idLogin,
                horaPonto: ponto.horaPonto,
                dataAprovacao: new Date().toISOString(),
                aprovadoPor: currentUser,
                foto: ponto.foto || null,
                justificativa: ponto.justificativa || null
            });
            await batch.commit();
            setPontos(prev => prev.filter(p => p.id !== ponto.id));
        } catch (error) {
            console.error("Erro ao aprovar ponto:", error);
            alert("Erro ao aprovar ponto. Tente novamente.");
        } finally {
            setLoadingForPonto(ponto.id, false);
        }
    };

    // Recusar ponto
    const handleRecusar = async (ponto) => {
        setLoadingForPonto(ponto.id, true);
        try {
            const currentUser = usuarioLogado?.name || "Administrador";
            const batch = writeBatch(db);
            const pontoRef = doc(db, "pontos", ponto.id);
            batch.update(pontoRef, { status: "Recusado", recusadoPor: currentUser, dataRecusa: new Date().toISOString() });
            const pontosEfetivadosRef = collection(db, "pontosEfetivados");
            batch.set(doc(pontosEfetivadosRef), {
                pontoId: ponto.id,
                status: "Recusado",
                usuario: ponto.usuario || "Desconhecido",
                idLogin: ponto.idLogin,
                horaPonto: ponto.horaPonto,
                dataRecusa: new Date().toISOString(),
                recusadoPor: currentUser,
                foto: ponto.foto || null,
                justificativa: ponto.justificativa || "Ponto recusado pelo gestor"
            });
            await batch.commit();
            setPontos(prev => prev.filter(p => p.id !== ponto.id));
        } catch (error) {
            console.error("Erro ao recusar ponto:", error);
            alert("Erro ao recusar ponto. Tente novamente.");
        } finally {
            setLoadingForPonto(ponto.id, false);
        }
    };

    // Registrar falta/abono
    const handleRegistrarStatus = async () => {
        if (!idLoginFalta || !justificativa) {
            alert("Preencha todos os campos!");
            return;
        }
        const usuarioAlvo = getUsuarioByIdLogin(idLoginFalta);
        if (!temPermissaoParaRegistrar(usuarioAlvo.permissao)) {
            alert("Você não tem permissão para registrar para este usuário!");
            return;
        }
        try {
            const collectionName = registroType === "Falta" ? "faltas" : "abonos";
            const currentUser = usuarioLogado?.name || "Administrador";
            await addDoc(collection(db, collectionName), {
                idLogin: idLoginFalta,
                usuario: usuarioAlvo.name || "Desconhecido",
                cargo: usuarioAlvo.role || "Desconhecido",
                status: registroType,
                justificativa: justificativa,
                registradoPor: currentUser,
                dataRegistro: new Date().toISOString(),
                pontoId: null,
                horaPonto: new Date().toISOString()
            });
            setShowRegistroModal(false);
            setIdLoginFalta("");
            setJustificativa("");
            setRegistroType("");
            alert(`${registroType} registrado com sucesso!`);
        } catch (error) {
            console.error("Erro ao registrar status:", error);
            alert("Erro ao registrar. Tente novamente.");
        }
    };

    const toggleSubmenu = (menu) => setSubmenuOpen(prev => ({ ...prev, [menu]: !prev[menu] }));

    const handleLogout = () => {
        logout();
        navigate('/login');
    };

    // Agrupar pontos por usuário
    const groupedPontos = pontos.reduce((acc, ponto) => {
        if (!acc[ponto.idLogin]) acc[ponto.idLogin] = [];
        acc[ponto.idLogin].push(ponto);
        return acc;
    }, {});

    if (!isAuthenticated) {
        navigate('/login');
        return null;
    }

    if (initialLoad) {
        return (
            <div className="app-loading">
                <div className="spinner"></div>
                <p>Carregando dados iniciais...</p>
            </div>
        );
    }

    return (
        <div className="app-container">
            {/* Sidebar */}
            <div className={`sidebar ${sidebarOpen ? 'open' : ''}`} ref={sidebarRef}>
                <div className="sidebar-header">
                    <h3 className="logo">Perequeté</h3>
                    <button className="toggle-btn" onClick={() => setSidebarOpen(!sidebarOpen)} aria-label={sidebarOpen ? "Recolher menu" : "Expandir menu"}>
                        <FiMenu />
                    </button>
                </div>

                <div className="user-profile">
                    <div className="avatar">{usuarioLogado?.name?.charAt(0) || <FiUser />}</div>
                    <div className="user-info">
                        <h5>{usuarioLogado?.name || 'Usuário'}</h5>
                        <span>{permissoesMap[usuarioLogado?.permissao] || 'Cargo'}</span>
                    </div>
                </div>

                <nav className="sidebar-nav">
                    <ul>
                        <li className={location.pathname === '/' ? 'active' : ''}>
                            <Link to="/login" className="menu-item">
                                <FiHome className="icon" /><span>Home</span>
                            </Link>
                        </li>

                        <li className="submenu-container">
                            <div className={`menu-item ${submenuOpen.usuarios ? 'open' : ''}`} onClick={() => toggleSubmenu('usuarios')}>
                                <FiUsers className="icon" /><span>Usuários</span>
                                <FiChevronRight className="arrow-icon" />
                            </div>
                            <ul className={`submenu ${submenuOpen.usuarios ? 'open' : ''}`}>
                                <li><Link to="/cadastro-usuarios">Cadastrar Usuário</Link></li>
                                <li><Link to="/lista-usuarios">Listar Usuários</Link></li>
                            </ul>
                        </li>

                        <li className="submenu-container">
                            <div className={`menu-item ${submenuOpen.relatorios ? 'open' : ''}`} onClick={() => toggleSubmenu('relatorios')}>
                                <FiFileText className="icon" /><span>Relatórios</span>
                                <FiChevronRight className="arrow-icon" />
                            </div>
                            <ul className={`submenu ${submenuOpen.relatorios ? 'open' : ''}`}>
                                <li><Link to="/relatorio-faltas">Faltas</Link></li>
                                <li><Link to="/relatorio-abonos">Abonos</Link></li>
                                <li><Link to="/relatorio-pontos">Pontos</Link></li>
                                <li><Link to="/planilha-mensal">Planilha Mensal</Link></li>
                            </ul>
                        </li>
                    </ul>
                </nav>

                <div className="sidebar-footer">
                    <button className="logout-btn" onClick={handleLogout} aria-label="Sair do sistema">
                        <FiLogOut className="icon" /><span>Sair</span>
                    </button>
                </div>
            </div>

            {/* Main Content */}
            <div className={`main-content ${sidebarOpen ? 'open' : ''}`}>
                <header className="main-header">
                    <div className="header-title">
                        <h1>Validar Pontos</h1>
                        <button className="btn-refresh" onClick={refreshData} disabled={isRefreshing}>
                            <FiRefreshCw className={isRefreshing ? 'spinning' : ''} />
                            {isRefreshing ? 'Atualizando...' : 'Atualizar'}
                        </button>
                    </div>
                    <div className="header-actions">
                        <button className="btn btn-primary" onClick={() => abrirRegistro("Falta")}>Registrar Falta</button>
                        <button className="btn btn-secondary" onClick={() => abrirRegistro("Abonado")}>Registrar Abono</button>
                    </div>
                </header>

                <div className="content-wrapper">
                    {pontos.length === 0 ? (
                        <div className="no-points">
                            <p>Não há pontos pendentes para validação</p>
                            <button className="btn" onClick={refreshData} disabled={isRefreshing}>
                                <FiRefreshCw className={isRefreshing ? 'spinning' : ''} />
                                {isRefreshing ? 'Atualizando...' : 'Recarregar'}
                            </button>
                        </div>
                    ) : (
                        <div className="pontos-grid">
                            {Object.keys(groupedPontos).map(idLogin => {
                                const usuarioPonto = getUsuarioByIdLogin(idLogin);
                                if (!temPermissaoParaVer(usuarioPonto.permissao)) return null;

                                return (
                                    <div key={idLogin} className="colaborador-card">
                                        <div className="colaborador-header">
                                            <div className="avatar">{usuarioPonto.name?.charAt(0) || '?'}</div>
                                            <div className="colaborador-info">
                                                <h3>{usuarioPonto.name || 'Usuário Desconhecido'}</h3>
                                                <p>{permissoesMap[usuarioPonto.permissao] || 'Cargo Desconhecido'}</p>
                                            </div>
                                        </div>

                                        <div className="pontos-list">
                                            {groupedPontos[idLogin].map(ponto => (
                                                <div key={ponto.id} className="ponto-card">
                                                    <div className="ponto-info">
                                                        <div className="ponto-hora"><FiClock /> {formatarData(ponto.horaPonto)}</div>
                                                        {ponto.foto && <img src={`data:image/png;base64,${ponto.foto}`} alt="Foto do Ponto" className="ponto-foto" onClick={() => setSelectedPonto(ponto)} />}
                                                    </div>
                                                    <div className="ponto-actions">
                                                        <button className="btn-approve" onClick={() => handleAprovar(ponto)} disabled={loadingPontos[ponto.id]}>
                                                            {loadingPontos[ponto.id] ? "Aprovando..." : <><FiCheck /> Aprovar</>}
                                                        </button>
                                                        <button className="btn-reject" onClick={() => handleRecusar(ponto)} disabled={loadingPontos[ponto.id]}>
                                                            {loadingPontos[ponto.id] ? "Recusando..." : <><FiX /> Recusar</>}
                                                        </button>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                );
                            })}

                            <div ref={loadMoreRef} className="load-more-trigger">
                                {dataLoading && <div className="loading-more"><div className="small-spinner"></div><p>Carregando mais pontos...</p></div>}
                                {!hasMore && <p className="no-more-data">Todos os pontos foram carregados</p>}
                            </div>
                        </div>
                    )}
                </div>
            </div>

            {/* Modal registro */}
            {showRegistroModal && (
                <div className="modal-overlay active">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h2>Registrar {registroType}</h2>
                            <button className="close-modal" onClick={() => setShowRegistroModal(false)}>&times;</button>
                        </div>
                        <div className="form-group">
                            <label>ID Login:</label>
                            <input type="text" value={idLoginFalta} onChange={(e) => setIdLoginFalta(e.target.value)} placeholder="Digite o ID Login" />
                        </div>
                        <div className="form-group">
                            <label>Justificativa:</label>
                            <textarea value={justificativa} onChange={(e) => setJustificativa(e.target.value)} placeholder="Digite a justificativa"></textarea>
                        </div>
                        <button className="btn btn-primary" onClick={handleRegistrarStatus}>Registrar</button>
                    </div>
                </div>
            )}

            {/* Modal foto ponto */}
            {selectedPonto && (
                <div className="modal-overlay active" onClick={() => setSelectedPonto(null)}>
                    <div className="modal-content" onClick={(e) => e.stopPropagation()}>
                        <h2>Foto do Ponto</h2>
                        <img src={`data:image/png;base64,${selectedPonto.foto}`} alt="Foto do Ponto" />
                        <button className="btn" onClick={() => setSelectedPonto(null)}>Fechar</button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ValidarPontos;
