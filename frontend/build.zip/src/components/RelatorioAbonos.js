import React from 'react';
import Relatorio from './RelatorioBase';

export default function RelatorioAbonos() {
    return <Relatorio titulo="Abonos" colecao="abonos" nomeAba="Abonos" filtrarStatus={true} />;
}
