import React from 'react';
import Relatorio from './RelatorioBase';

export default function RelatorioFaltas() {
    return <Relatorio titulo="Faltas" colecao="faltas" nomeAba="Faltas" />;
}
