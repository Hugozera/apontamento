import React, { useState, useEffect, useMemo } from 'react';
import { collection, getDocs, query, orderBy, where } from 'firebase/firestore';
import { db } from '../../config/firebase';
import * as XLSX from 'xlsx';
import { Modal, Button, Form, Row, Col, Spinner, Tab, Tabs, Card, Badge, Table } from 'react-bootstrap';
import Layout from '../TemplateLayout';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import '../Relatorios.css';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { registerLocale, setDefaultLocale } from 'react-datepicker';
import ptBR from 'date-fns/locale/pt-BR';

// Configuração do calendário brasileiro
registerLocale('pt-BR', ptBR);
setDefaultLocale('pt-BR');

// Tipos de registro
const TIPOS_REGISTRO = {
    ENTRADA: 'entrada',
    SAIDA_ALMOCO: 'saidaAlmoco',
    VOLTA_ALMOCO: 'voltaAlmoco',
    SAIDA: 'saida',
    DIA_TRABALHO: 'diaTrabalho',
    FALTA: 'falta'
};

// Configurações de jornada
const JORNADAS = {
    '12/36': {
        nome: '12/36',
        entrada: 7 * 60,      // 07:00 (420 minutos)
        saidaAlmoco: 12 * 60, // 12:00 (720 minutos)
        voltaAlmoco: 13 * 60, // 13:00 (780 minutos)
        saida: 19 * 60,       // 19:00 (1140 minutos)
        cargaHoraria: 12 * 60 // 12 horas em minutos
    },
    '6/1': {
        nome: '6/1',
        entrada: 8 * 60,      // 08:00
        saidaAlmoco: 12 * 60, // 12:00
        voltaAlmoco: 13 * 60, // 13:00
        saida: 17 * 60,       // 17:00
        cargaHoraria: 8 * 60  // 8 horas
    }
};

// ==============================================
// FUNÇÕES AUXILIARES CORRIGIDAS
// ==============================================

/**
 * Converte qualquer formato de data/hora para objeto Date
 * @param {any} horaPonto - Pode ser: string "dd/MM/yyyy HH:mm:ss", Date, Timestamp ou outro formato
 * @returns {Date|null} Retorna o objeto Date ou null se não for possível converter
 */
function parseDataHora(horaPonto) {
    // Caso já seja null/undefined ou string vazia
    if (!horaPonto) return null;

    // Se já for um objeto Date válido
    if (horaPonto instanceof Date && !isNaN(horaPonto.getTime())) {
        return horaPonto;
    }

    // Se for Timestamp do Firestore (com método toDate)
    if (typeof horaPonto === 'object' && horaPonto.toDate instanceof Function) {
        return horaPonto.toDate();
    }

    // Formato string "dd/MM/yyyy HH:mm:ss" (seu formato atual)
    if (typeof horaPonto === 'string' && horaPonto.includes('/')) {
        try {
            const [datePart, timePart] = horaPonto.split(' ');
            const [day, month, year] = datePart.split('/');
            const [hours, minutes, seconds] = timePart?.split(':') || ['00', '00', '00'];

            // Cria a data (mês é 0-based, por isso month-1)
            return new Date(
                parseInt(year),
                parseInt(month) - 1,
                parseInt(day),
                parseInt(hours),
                parseInt(minutes),
                parseInt(seconds)
            );
        } catch (e) {
            console.error('Erro ao converter string para data:', horaPonto, e);
            return null;
        }
    }

    // Tentativa genérica (para outros formatos ou ISO strings)
    try {
        const date = new Date(horaPonto);
        return isNaN(date.getTime()) ? null : date;
    } catch (e) {
        console.error('Erro ao converter data genérica:', horaPonto, e);
        return null;
    }
}
function extrairMesAno(data) {
    const date = parseDataHora(data);
    if (!date) return null;
    return {
        mes: date.getMonth() + 1, // Janeiro = 1
        ano: date.getFullYear()
    };
}

function formatarDataSimples(date) {
    if (!date) return '';
    const d = parseDataHora(date);
    return d.toISOString().split('T')[0];
}

function formatarDataBR(dateString) {
    const date = parseDataHora(dateString);
    if (!date) return '-';
    return date.toLocaleDateString('pt-BR');
}

function formatarHora(horaPonto) {
    const date = parseDataHora(horaPonto);
    if (!date) return '-';
    return date.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
}

function calcularMinutos(hora) {
    if (!hora) return 0;
    const date = parseDataHora(hora);
    if (!date) return 0;
    return date.getHours() * 60 + date.getMinutes();
}

function formatarMinutosParaHora(minutos) {
    if (minutos === 0 || minutos === null || minutos === undefined) return '-';
    const horas = Math.floor(Math.abs(minutos) / 60);
    const mins = Math.abs(minutos) % 60;
    const sinal = minutos < 0 ? '-' : '';
    return `${sinal}${horas.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}`;
}

// Função corrigida para classificar os pontos na ordem correta
function classificarPontos(pontos) {
    if (!pontos || pontos.length === 0) return {
        entrada: null,
        saidaAlmoco: null,
        voltaAlmoco: null,
        saidaFinal: null
    };

    // Ordena os pontos por horário (do mais antigo para o mais recente)
    const pontosOrdenados = [...pontos].sort((a, b) => {
        const dataA = parseDataHora(a.horaPonto);
        const dataB = parseDataHora(b.horaPonto);
        return dataA - dataB;
    });

    // Classifica os pontos na ordem correta
    const resultado = {
        entrada: pontosOrdenados[0]?.horaPonto || null,
        saidaAlmoco: pontosOrdenados[1]?.horaPonto || null,
        voltaAlmoco: pontosOrdenados[2]?.horaPonto || null,
        saidaFinal: pontosOrdenados[3]?.horaPonto || null
    };

    return resultado;
}

function calcularTotaisDia(pontosClassificados, abonos = [], falta = false, jornadaConfig) {
    if (falta) {
        return {
            horasTrabalhadas: 0,
            horasExtras: 0,
            atrasoEntrada: 0,
            atrasoVoltaAlmoco: 0,
            saidaAntecipada: 0,
            observacoes: 'Falta registrada',
            abonos
        };
    }

    const diaAbonado = abonos.some(abono => abono.tipoAbonado === TIPOS_REGISTRO.DIA_TRABALHO);
    if (diaAbonado) {
        return {
            horasTrabalhadas: jornadaConfig.cargaHoraria,
            horasExtras: 0,
            atrasoEntrada: 0,
            atrasoVoltaAlmoco: 0,
            saidaAntecipada: 0,
            observacoes: 'Dia abonado',
            abonos
        };
    }

    const entradaAbonada = abonos.some(abono => abono.tipoAbonado === TIPOS_REGISTRO.ENTRADA);
    const saidaAlmocoAbonada = abonos.some(abono => abono.tipoAbonado === TIPOS_REGISTRO.SAIDA_ALMOCO);
    const voltaAlmocoAbonada = abonos.some(abono => abono.tipoAbonado === TIPOS_REGISTRO.VOLTA_ALMOCO);
    const saidaAbonada = abonos.some(abono => abono.tipoAbonado === TIPOS_REGISTRO.SAIDA);

    const entradaMin = entradaAbonada ? jornadaConfig.entrada : calcularMinutos(pontosClassificados.entrada);
    const saidaAlmocoMin = saidaAlmocoAbonada ? jornadaConfig.saidaAlmoco : calcularMinutos(pontosClassificados.saidaAlmoco);
    const voltaAlmocoMin = voltaAlmocoAbonada ? jornadaConfig.voltaAlmoco : calcularMinutos(pontosClassificados.voltaAlmoco);
    const saidaMin = saidaAbonada ? jornadaConfig.saida : calcularMinutos(pontosClassificados.saidaFinal);

    const pontosSuficientes = entradaMin > 0 && saidaMin > 0;
    if (!pontosSuficientes) {
        return {
            horasTrabalhadas: 0,
            horasExtras: 0,
            atrasoEntrada: 0,
            atrasoVoltaAlmoco: 0,
            saidaAntecipada: 0,
            observacoes: 'Falta registro de ponto',
            abonos
        };
    }

    const manha = saidaAlmocoMin > 0 ? (saidaAlmocoMin - entradaMin) : 0;
    const tarde = voltaAlmocoMin > 0 ? (saidaMin - voltaAlmocoMin) : 0;
    const horasTrabalhadas = manha + tarde;
    const diferenca = horasTrabalhadas - jornadaConfig.cargaHoraria;

    const atrasoEntrada = entradaAbonada ? 0 : Math.max(0, entradaMin - jornadaConfig.entrada);
    const atrasoVoltaAlmoco = voltaAlmocoAbonada ? 0 : (voltaAlmocoMin > 0 ? Math.max(0, voltaAlmocoMin - jornadaConfig.voltaAlmoco) : 0);
    const saidaAntecipada = saidaAbonada ? 0 : Math.max(0, jornadaConfig.saida - saidaMin);

    const observacoesAbonos = [];
    if (entradaAbonada) observacoesAbonos.push('Entrada abonada');
    if (saidaAlmocoAbonada) observacoesAbonos.push('Saída almoço abonada');
    if (voltaAlmocoAbonada) observacoesAbonos.push('Volta almoço abonada');
    if (saidaAbonada) observacoesAbonos.push('Saída abonada');

    return {
        horasTrabalhadas,
        horasExtras: Math.max(0, diferenca),
        atrasoEntrada,
        atrasoVoltaAlmoco,
        saidaAntecipada,
        observacoes: observacoesAbonos.join(', ') || 'Normal',
        abonos
    };
}

// ==============================================
// COMPONENTES AUXILIARES
// ==============================================

const FiltrosAvancados = ({
                              filtros,
                              setFiltros,
                              departamentos,
                              handleAplicarFiltros,
                              handleLimparFiltros
                          }) => {
    return (
        <Card className="mb-4">
            <Card.Header>Filtros Avançados</Card.Header>
            <Card.Body>
                <Form>
                    <Row>
                        <Col md={3}>
                            <Form.Group>
                                <Form.Label>Período Inicial</Form.Label>
                                <DatePicker
                                    selected={filtros.dataInicio}
                                    onChange={(date) => setFiltros({...filtros, dataInicio: date})}
                                    dateFormat="dd/MM/yyyy"
                                    className="form-control"
                                    placeholderText="Selecione a data"
                                    locale="pt-BR"
                                    showMonthDropdown
                                    showYearDropdown
                                    dropdownMode="select"
                                />
                            </Form.Group>
                        </Col>
                        <Col md={3}>
                            <Form.Group>
                                <Form.Label>Período Final</Form.Label>
                                <DatePicker
                                    selected={filtros.dataFim}
                                    onChange={(date) => setFiltros({...filtros, dataFim: date})}
                                    dateFormat="dd/MM/yyyy"
                                    className="form-control"
                                    placeholderText="Selecione a data"
                                    locale="pt-BR"
                                    showMonthDropdown
                                    showYearDropdown
                                    dropdownMode="select"
                                />
                            </Form.Group>
                        </Col>
                        <Col md={3}>
                            <Form.Group>
                                <Form.Label>Departamento</Form.Label>
                                <Form.Control
                                    as="select"
                                    value={filtros.departamento}
                                    onChange={(e) => setFiltros({...filtros, departamento: e.target.value})}
                                >
                                    <option value="">Todos</option>
                                    {departamentos.map((depto, index) => (
                                        <option key={index} value={depto}>{depto}</option>
                                    ))}
                                </Form.Control>
                            </Form.Group>
                        </Col>
                        <Col md={3}>
                            <Form.Group>
                                <Form.Label>Jornada</Form.Label>
                                <Form.Control
                                    as="select"
                                    value={filtros.jornada}
                                    onChange={(e) => setFiltros({...filtros, jornada: e.target.value})}
                                >
                                    <option value="">Todas</option>
                                    {Object.keys(JORNADAS).map((jornada, index) => (
                                        <option key={index} value={jornada}>{jornada}</option>
                                    ))}
                                </Form.Control>
                            </Form.Group>
                        </Col>
                    </Row>
                    <Row className="mt-3">
                        <Col md={12} className="d-flex justify-content-end">
                            <Button variant="secondary" onClick={handleLimparFiltros} className="me-2">
                                Limpar Filtros
                            </Button>
                            <Button variant="primary" onClick={handleAplicarFiltros}>
                                Aplicar Filtros
                            </Button>
                        </Col>
                    </Row>
                </Form>
            </Card.Body>
        </Card>
    );
};

const GraficosAnaliticos = ({ dados }) => {
    const dadosGrafico = useMemo(() => {
        return dados.map(usuario => ({
            nome: usuario.usuario,
            horasExtras: usuario.totais.horasExtras / 60,
            atrasos: usuario.totais.atrasos / 60,
            faltas: usuario.totais.faltas
        }));
    }, [dados]);

    return (
        <Card className="mb-4">
            <Card.Header>Análise Gráfica</Card.Header>
            <Card.Body>
                <Tabs defaultActiveKey="horasExtras" className="mb-3">
                    <Tab eventKey="horasExtras" title="Horas Extras">
                        <div style={{ height: '400px' }}>
                            <ResponsiveContainer width="100%" height="100%">
                                <BarChart
                                    data={dadosGrafico}
                                    margin={{ top: 20, right: 30, left: 20, bottom: 80 }}
                                >
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis dataKey="nome" angle={-45} textAnchor="end" height={70} />
                                    <YAxis label={{ value: 'Horas', angle: -90, position: 'insideLeft' }} />
                                    <Tooltip />
                                    <Legend />
                                    <Bar dataKey="horasExtras" name="Horas Extras" fill="#28a745" />
                                </BarChart>
                            </ResponsiveContainer>
                        </div>
                    </Tab>
                    <Tab eventKey="atrasos" title="Atrasos">
                        <div style={{ height: '400px' }}>
                            <ResponsiveContainer width="100%" height="100%">
                                <BarChart
                                    data={dadosGrafico}
                                    margin={{ top: 20, right: 30, left: 20, bottom: 80 }}
                                >
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis dataKey="nome" angle={-45} textAnchor="end" height={70} />
                                    <YAxis label={{ value: 'Horas', angle: -90, position: 'insideLeft' }} />
                                    <Tooltip />
                                    <Legend />
                                    <Bar dataKey="atrasos" name="Atrasos (horas)" fill="#ffc107" />
                                </BarChart>
                            </ResponsiveContainer>
                        </div>
                    </Tab>
                    <Tab eventKey="faltas" title="Faltas">
                        <div style={{ height: '400px' }}>
                            <ResponsiveContainer width="100%" height="100%">
                                <BarChart
                                    data={dadosGrafico}
                                    margin={{ top: 20, right: 30, left: 20, bottom: 80 }}
                                >
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis dataKey="nome" angle={-45} textAnchor="end" height={70} />
                                    <YAxis label={{ value: 'Quantidade', angle: -90, position: 'insideLeft' }} />
                                    <Tooltip />
                                    <Legend />
                                    <Bar dataKey="faltas" name="Faltas" fill="#dc3545" />
                                </BarChart>
                            </ResponsiveContainer>
                        </div>
                    </Tab>
                </Tabs>
            </Card.Body>
        </Card>
    );
};

const Paginacao = ({ paginaAtual, totalPaginas, mudarPagina }) => {
    const paginasParaMostrar = 5;
    let inicio = Math.max(1, paginaAtual - Math.floor(paginasParaMostrar / 2));
    let fim = Math.min(totalPaginas, inicio + paginasParaMostrar - 1);

    if (fim - inicio + 1 < paginasParaMostrar) {
        inicio = Math.max(1, fim - paginasParaMostrar + 1);
    }

    const paginas = [];
    for (let i = inicio; i <= fim; i++) {
        paginas.push(i);
    }

    return (
        <nav aria-label="Page navigation">
            <ul className="pagination justify-content-center">
                <li className={`page-item ${paginaAtual === 1 ? 'disabled' : ''}`}>
                    <button className="page-link" onClick={() => mudarPagina(1)}>
                        &laquo;
                    </button>
                </li>
                <li className={`page-item ${paginaAtual === 1 ? 'disabled' : ''}`}>
                    <button className="page-link" onClick={() => mudarPagina(paginaAtual - 1)}>
                        &lsaquo;
                    </button>
                </li>

                {inicio > 1 && (
                    <li className="page-item disabled">
                        <span className="page-link">...</span>
                    </li>
                )}

                {paginas.map(num => (
                    <li key={num} className={`page-item ${paginaAtual === num ? 'active' : ''}`}>
                        <button className="page-link" onClick={() => mudarPagina(num)}>
                            {num}
                        </button>
                    </li>
                ))}

                {fim < totalPaginas && (
                    <li className="page-item disabled">
                        <span className="page-link">...</span>
                    </li>
                )}

                <li className={`page-item ${paginaAtual === totalPaginas ? 'disabled' : ''}`}>
                    <button className="page-link" onClick={() => mudarPagina(paginaAtual + 1)}>
                        &rsaquo;
                    </button>
                </li>
                <li className={`page-item ${paginaAtual === totalPaginas ? 'disabled' : ''}`}>
                    <button className="page-link" onClick={() => mudarPagina(totalPaginas)}>
                        &raquo;
                    </button>
                </li>
            </ul>
        </nav>
    );
};

const RelatorioImpressao = ({ empresa, usuario, registros, periodo, onClose, jornadaConfig }) => {
    const totais = {
        horasExtras: registros.reduce((sum, item) => sum + (item.totaisDia.horasExtras || 0), 0),
        atrasos: registros.reduce((sum, item) => sum + (item.totaisDia.atrasoEntrada || 0) + (item.totaisDia.atrasoVoltaAlmoco || 0), 0),
        diasTrabalhados: registros.filter(item => item.totaisDia.horasTrabalhadas > 0).length,
        diasAbonados: registros.filter(item => item.totaisDia.observacoes.includes('Dia abonado')).length,
        faltas: registros.filter(item => item.totaisDia.observacoes.includes('Falta')).length
    };

    return (
        <div className="relatorio-impressao-profissional">
            <div className="cabecalho-empresa">
                <div className="logo-container">
                    {empresa.logo && <img src={empresa.logo} alt="Logo" className="logo-empresa" />}
                </div>
                <div className="dados-empresa">
                    <h1>{empresa.razaoSocial}</h1>
                    <p className="cnpj">CNPJ: {empresa.cnpj}</p>
                    <p className="endereco">{empresa.endereco}</p>
                </div>
            </div>

            <div className="titulo-relatorio">
                <h2>RELATÓRIO DE PONTO INDIVIDUAL</h2>
                <p className="periodo">Período: {periodo}</p>
                <p className="jornada">Jornada: {usuario.jornada}</p>
            </div>

            <div className="dados-funcionario">
                <div className="row">
                    <div className="col-md-6">
                        <p><strong>Nome:</strong> {usuario.nome}</p>
                        <p><strong>ID:</strong> {usuario.idLogin}</p>
                    </div>
                    <div className="col-md-6">
                        <p><strong>Departamento:</strong> {usuario.departamento}</p>
                        <p><strong>Cargo:</strong> {usuario.cargo || 'Não informado'}</p>
                    </div>
                </div>
            </div>

            <div className="tabela-container">
                <table className="tabela-impressao">
                    <thead>
                    <tr>
                        <th style={{ width: '10%' }}>Data</th>
                        <th style={{ width: '12%' }}>Entrada</th>
                        <th style={{ width: '12%' }}>Saída Almoço</th>
                        <th style={{ width: '12%' }}>Volta Almoço</th>
                        <th style={{ width: '12%' }}>Saída Final</th>
                        <th style={{ width: '10%' }}>Horas</th>
                        <th style={{ width: '10%' }}>Extras</th>
                        <th style={{ width: '12%' }}>Atrasos</th>
                        <th style={{ width: '10%' }}>Situação</th>
                    </tr>
                    </thead>
                    <tbody>
                    {registros.map((item, index) => (
                        <tr key={index} className={item.totaisDia.observacoes.includes('Falta') ? 'falta' :
                            item.totaisDia.observacoes.includes('abonado') ? 'abono' : ''}>
                            <td>{formatarDataBR(item.data)}</td>
                            <td>{item.entrada ? formatarHora(item.entrada) :
                                (item.totaisDia.abonos?.some(a => a.tipoAbonado === TIPOS_REGISTRO.ENTRADA) ? 'Abonado' : '-')}</td>
                            <td>{item.saidaAlmoco ? formatarHora(item.saidaAlmoco) :
                                (item.totaisDia.abonos?.some(a => a.tipoAbonado === TIPOS_REGISTRO.SAIDA_ALMOCO) ? 'Abonado' : '-')}</td>
                            <td>{item.voltaAlmoco ? formatarHora(item.voltaAlmoco) :
                                (item.totaisDia.abonos?.some(a => a.tipoAbonado === TIPOS_REGISTRO.VOLTA_ALMOCO) ? 'Abonado' : '-')}</td>
                            <td>{item.saidaFinal ? formatarHora(item.saidaFinal) :
                                (item.totaisDia.abonos?.some(a => a.tipoAbonado === TIPOS_REGISTRO.SAIDA) ? 'Abonado' : '-')}</td>
                            <td>{formatarMinutosParaHora(item.totaisDia.horasTrabalhadas)}</td>
                            <td>{formatarMinutosParaHora(item.totaisDia.horasExtras)}</td>
                            <td>
                                {item.totaisDia.atrasoEntrada > 0 && `E:${formatarMinutosParaHora(item.totaisDia.atrasoEntrada)}`}
                                {item.totaisDia.atrasoVoltaAlmoco > 0 && ` V:${formatarMinutosParaHora(item.totaisDia.atrasoVoltaAlmoco)}`}
                                {(item.totaisDia.atrasoEntrada === 0 && item.totaisDia.atrasoVoltaAlmoco === 0) && '-'}
                            </td>
                            <td>{item.totaisDia.observacoes}</td>
                        </tr>
                    ))}
                    </tbody>
                </table>
            </div>

            <div className="totais-impressao">
                <div className="row">
                    <div className="col-md-3">
                        <p><strong>Total Horas Extras:</strong> {formatarMinutosParaHora(totais.horasExtras)}</p>
                    </div>
                    <div className="col-md-3">
                        <p><strong>Total Atrasos:</strong> {formatarMinutosParaHora(totais.atrasos)}</p>
                    </div>
                    <div className="col-md-2">
                        <p><strong>Dias Trab.:</strong> {totais.diasTrabalhados}</p>
                    </div>
                    <div className="col-md-2">
                        <p><strong>Dias Abon.:</strong> {totais.diasAbonados}</p>
                    </div>
                    <div className="col-md-2">
                        <p><strong>Faltas:</strong> {totais.faltas}</p>
                    </div>
                </div>
            </div>

            <div className="assinaturas">
                <div className="assinatura-funcionario">
                    <div className="linha-assinatura"></div>
                    <p>{usuario.nome}</p>
                    <p>Assinatura do Funcionário</p>
                </div>
                <div className="assinatura-gestor">
                    <div className="linha-assinatura"></div>
                    <p>{empresa.gestor || 'Responsável'}</p>
                    <p>Assinatura do Gestor</p>
                </div>
            </div>

            <div className="rodape-impressao">
                <p>Emitido em: {new Date().toLocaleDateString('pt-BR')} às {new Date().toLocaleTimeString('pt-BR', {hour: '2-digit', minute:'2-digit'})}</p>
                <p>Jornada de referência: {usuario.jornada} | Horários: Entrada: {formatarMinutosParaHora(jornadaConfig.entrada)}, Saída Almoço: {formatarMinutosParaHora(jornadaConfig.saidaAlmoco)}, Volta Almoço: {formatarMinutosParaHora(jornadaConfig.voltaAlmoco)}, Saída: {formatarMinutosParaHora(jornadaConfig.saida)}</p>
            </div>

            <div className="botoes-impressao no-print">
                <Button variant="secondary" onClick={onClose} className="me-2">
                    Fechar
                </Button>
                <Button variant="primary" onClick={() => window.print()}>
                    Imprimir
                </Button>
            </div>
        </div>
    );
};

// ==============================================
// COMPONENTE PRINCIPAL CORRIGIDO
// ==============================================

export default function PlanilhaMensalCompleta() {
    const [dadosAgrupados, setDadosAgrupados] = useState([]);
    const [totaisPorUsuario, setTotaisPorUsuario] = useState({});
    const [carregando, setCarregando] = useState(false);
    const [empresa, setEmpresa] = useState(null);
    const [usuarioImpressao, setUsuarioImpressao] = useState(null);
    const [periodoImpressao, setPeriodoImpressao] = useState('');
    const [showImpressao, setShowImpressao] = useState(false);
    const [usuarios, setUsuarios] = useState([]);
    const [departamentos, setDepartamentos] = useState([]);
    const [filtros, setFiltros] = useState({
        dataInicio: null,
        dataFim: null,
        departamento: '',
        jornada: '',
        busca: ''
    });
    const [paginaAtual, setPaginaAtual] = useState(1);
    const [itensPorPagina] = useState(5);
    const [jornadaAtiva, setJornadaAtiva] = useState('12/36');

    useEffect(() => {
        const carregarDadosIniciais = async () => {
            setCarregando(true);
            try {
                // Carrega dados da empresa
                const empresaSnapshot = await getDocs(collection(db, 'empresa'));
                setEmpresa(empresaSnapshot.docs[0]?.data() || {
                    razaoSocial: 'Auto Posto Perequete',
                    cnpj: '56.102.541.0001/85',
                    endereco: 'Quadra 712 sul al 01 lt S/N Plano Diretor Sul',
                    gestor: 'Diogo Crêstani'
                });

                // Carrega lista de usuários
                const usuariosSnapshot = await getDocs(collection(db, 'users'));
                const usuariosData = usuariosSnapshot.docs.map(doc => ({
                    id: doc.id,
                    ...doc.data(),
                    idLogin: doc.data().idLogin ? doc.data().idLogin.toString() : '',
                    jornada: doc.data().jornada || '12/36'
                }));

                setUsuarios(usuariosData);

                // Extrai departamentos únicos
                const deptos = [...new Set(usuariosData.map(u => u.departamento).filter(Boolean))];
                setDepartamentos(deptos);

                // Carrega pontos, abonos e faltas
                await carregarDadosPontos(usuariosData);
            } catch (error) {
                console.error('Erro ao carregar dados iniciais:', error);
            } finally {
                setCarregando(false);
            }
        };

        carregarDadosIniciais();
    }, []);

    async function carregarDadosPontos(usuariosData) {
        try {
            setCarregando(true);

            // 1. Filtra usuários
            let usuariosFiltrados = usuariosData.filter(user => {
                const deptoMatch = !filtros.departamento || user.departamento === filtros.departamento;
                const jornadaMatch = !filtros.jornada || user.jornada === filtros.jornada;
                return deptoMatch && jornadaMatch;
            });

            if (usuariosFiltrados.length === 0) {
                setDadosAgrupados([]);
                setTotaisPorUsuario({});
                return;
            }

            // 2. Configura período do filtro
            let dataInicioFiltro = null;
            let dataFimFiltro = null;

            if (filtros.dataInicio) {
                dataInicioFiltro = new Date(filtros.dataInicio);
                dataInicioFiltro.setHours(0, 0, 0, 0);
            }

            if (filtros.dataFim) {
                dataFimFiltro = new Date(filtros.dataFim);
                dataFimFiltro.setHours(23, 59, 59, 999);
            }

            // 3. Função para normalizar datas
            const parseData = (data) => {
                if (!data) return null;

                // Se for Timestamp do Firestore
                if (typeof data === 'object' && 'toDate' in data) {
                    return data.toDate();
                }

                // Se for string no formato "dd/MM/yyyy HH:mm:ss"
                if (typeof data === 'string' && data.includes('/')) {
                    const [datePart, timePart] = data.split(' ');
                    const [day, month, year] = datePart.split('/');
                    const [hours, minutes, seconds] = timePart?.split(':') || ['00', '00', '00'];
                    return new Date(year, month - 1, day, hours, minutes, seconds);
                }

                // Tentativa genérica
                return new Date(data);
            };

            // 4. Consulta todos os pontos (sem filtro inicial no Firestore para evitar problemas com formato string)
            const qPontos = query(collection(db, 'pontosEfetivados'), orderBy('horaPonto', 'asc'));
            const qAbonos = query(collection(db, 'abonos'), orderBy('data', 'asc'));
            const qFaltas = query(collection(db, 'faltas'), orderBy('data', 'asc'));

            const [snapshotPontos, snapshotAbonos, snapshotFaltas] = await Promise.all([
                getDocs(qPontos),
                getDocs(qAbonos),
                getDocs(qFaltas)
            ]);

            // 5. Processa e filtra os pontos
            const idsUsuariosFiltrados = usuariosFiltrados.map(u => u.name);

            const todosPontos = snapshotPontos.docs
                .map(doc => {
                    const data = doc.data();
                    const dataConvertida = parseData(data.horaPonto);

                    return {
                        id: doc.id,
                        ...data,
                        horaPontoDate: dataConvertida,
                        dataStr: dataConvertida ? formatarDataSimples(dataConvertida) : ''
                    };
                })
                .filter(ponto => {
                    // Filtro por usuário
                    if (!idsUsuariosFiltrados.includes(ponto.usuario)) {
                        return false;
                    }

                    // Filtro por data
                    if (!ponto.horaPontoDate) return false;

                    if (dataInicioFiltro && ponto.horaPontoDate < dataInicioFiltro) {
                        return false;
                    }

                    if (dataFimFiltro && ponto.horaPontoDate > dataFimFiltro) {
                        return false;
                    }

                    return true;
                });

            // Processa abonos
            const todosAbonos = snapshotAbonos.docs
                .map(doc => {
                    const data = doc.data();
                    return {
                        id: doc.id,
                        ...data,
                        dataDate: parseData(data.data)
                    };
                })
                .filter(abono => idsUsuariosFiltrados.includes(abono.usuario));

            // Processa faltas
            const todasFaltas = snapshotFaltas.docs
                .map(doc => {
                    const data = doc.data();
                    return {
                        id: doc.id,
                        ...data,
                        dataDate: parseData(data.data)
                    };
                })
                .filter(falta => idsUsuariosFiltrados.includes(falta.usuario));

            // 6. Agrupamento de dados
            const agrupados = {};
            const totaisUsuario = {};
            const abonosAgrupados = {};
            const faltasAgrupadas = {};

            // Inicializa totais por usuário
            usuariosFiltrados.forEach(user => {
                totaisUsuario[user.name] = {
                    horasExtras: 0,
                    atrasos: 0,
                    diasTrabalhados: 0,
                    diasAbonados: 0,
                    faltas: 0,
                    jornada: user.jornada || '12/36',
                    departamento: user.departamento || 'Não informado',
                    idLogin: user.idLogin || ''
                };
            });

            // Agrupa abonos por usuário e data
            todosAbonos.forEach(abono => {
                const dataStr = formatarDataSimples(abono.dataDate);
                const chave = `${abono.usuario}_${dataStr}`;
                if (!abonosAgrupados[chave]) abonosAgrupados[chave] = [];
                abonosAgrupados[chave].push(abono);
            });

            // Agrupa faltas por usuário e data
            todasFaltas.forEach(falta => {
                const dataStr = formatarDataSimples(falta.dataDate);
                const chave = `${falta.usuario}_${dataStr}`;
                faltasAgrupadas[chave] = true;
            });

            // Agrupa pontos por usuário e data
            todosPontos.forEach(ponto => {
                const dataStr = formatarDataSimples(ponto.horaPontoDate);
                const chave = `${ponto.usuario}_${dataStr}`;

                if (!agrupados[chave]) {
                    const usuario = usuariosData.find(u => u.name === ponto.usuario);
                    agrupados[chave] = {
                        usuario: ponto.usuario,
                        idLogin: ponto.idLogin || '',
                        data: dataStr,
                        pontos: [],
                        abonos: abonosAgrupados[chave] || [],
                        falta: faltasAgrupadas[chave] || false,
                        jornada: usuario?.jornada || '12/36'
                    };
                }
                agrupados[chave].pontos.push(ponto);
            });

            // Adiciona abonos sem pontos correspondentes
            Object.keys(abonosAgrupados).forEach(chave => {
                if (!agrupados[chave]) {
                    const [usuario, data] = chave.split('_');
                    const user = usuariosData.find(u => u.name === usuario);
                    agrupados[chave] = {
                        usuario,
                        idLogin: abonosAgrupados[chave][0]?.idLogin || '',
                        data,
                        pontos: [],
                        abonos: abonosAgrupados[chave],
                        falta: faltasAgrupadas[chave] || false,
                        jornada: user?.jornada || '12/36'
                    };
                }
            });

            // Adiciona faltas sem pontos/abonos correspondentes
            Object.keys(faltasAgrupadas).forEach(chave => {
                if (!agrupados[chave]) {
                    const [usuario, data] = chave.split('_');
                    const user = usuariosData.find(u => u.name === usuario);
                    agrupados[chave] = {
                        usuario,
                        idLogin: '',
                        data,
                        pontos: [],
                        abonos: [],
                        falta: true,
                        jornada: user?.jornada || '12/36'
                    };
                }
            });

            // 7. Calcula totais e classifica pontos
            const listaFinal = Object.values(agrupados).map(item => {
                const jornadaConfig = JORNADAS[item.jornada] || JORNADAS['12/36'];
                const pontosClassificados = classificarPontos(item.pontos);
                const totaisDia = calcularTotaisDia(pontosClassificados, item.abonos, item.falta, jornadaConfig);

                // Atualiza totais por usuário
                if (totaisUsuario[item.usuario]) {
                    if (totaisDia.observacoes.includes('Dia abonado')) {
                        totaisUsuario[item.usuario].diasAbonados += 1;
                    } else if (totaisDia.observacoes.includes('Falta')) {
                        totaisUsuario[item.usuario].faltas += 1;
                    } else if (totaisDia.horasTrabalhadas > 0) {
                        totaisUsuario[item.usuario].horasExtras += totaisDia.horasExtras;
                        totaisUsuario[item.usuario].atrasos += totaisDia.atrasoEntrada + totaisDia.atrasoVoltaAlmoco;
                        totaisUsuario[item.usuario].diasTrabalhados += 1;
                    }
                }

                return {
                    ...item,
                    ...pontosClassificados,
                    totaisDia
                };
            });

            // 8. Atualiza estado
            setDadosAgrupados(listaFinal);
            setTotaisPorUsuario(totaisUsuario);

        } catch (error) {
            console.error('Erro ao carregar dados:', error);
            setDadosAgrupados([]);
            setTotaisPorUsuario({});
        } finally {
            setCarregando(false);
        }
    }

    const handleAplicarFiltros = () => {
        setPaginaAtual(1);
        carregarDadosPontos(usuarios);
    };

    const handleLimparFiltros = () => {
        setFiltros({
            dataInicio: null,
            dataFim: null,
            departamento: '',
            jornada: '',
            busca: ''
        });
        setPaginaAtual(1);
        carregarDadosPontos(usuarios);
    };

    const prepararImpressao = (usuario) => {
        const registrosUsuario = dadosAgrupados
            .filter(item => item.usuario === usuario)
            .sort((a, b) => new Date(a.data) - new Date(b.data));

        const datas = registrosUsuario.map(item => new Date(item.data));
        const dataInicio = new Date(Math.min(...datas));
        const dataFim = new Date(Math.max(...datas));
        const periodo = `${dataInicio.toLocaleDateString('pt-BR')} a ${dataFim.toLocaleDateString('pt-BR')}`;

        setUsuarioImpressao({
            nome: usuario,
            idLogin: registrosUsuario[0]?.idLogin || '',
            departamento: totaisPorUsuario[usuario]?.departamento || 'Não informado',
            jornada: totaisPorUsuario[usuario]?.jornada || '12/36',
            totais: totaisPorUsuario[usuario] || {}
        });
        setPeriodoImpressao(periodo);
        setShowImpressao(true);
    };

    function exportarExcel() {
        try {
            // Dados detalhados
            const dadosDetalhados = dadosAgrupados.map(item => ({
                Usuário: item.usuario,
                'ID Login': item.idLogin,
                Data: formatarDataBR(item.data),
                Jornada: item.jornada,
                Entrada: item.entrada ? formatarHora(item.entrada) :
                    (item.totaisDia.abonos?.some(a => a.tipoAbonado === TIPOS_REGISTRO.ENTRADA) ? 'Abonado' : '-'),
                'Saída Almoço': item.saidaAlmoco ? formatarHora(item.saidaAlmoco) :
                    (item.totaisDia.abonos?.some(a => a.tipoAbonado === TIPOS_REGISTRO.SAIDA_ALMOCO) ? 'Abonado' : '-'),
                'Volta Almoço': item.voltaAlmoco ? formatarHora(item.voltaAlmoco) :
                    (item.totaisDia.abonos?.some(a => a.tipoAbonado === TIPOS_REGISTRO.VOLTA_ALMOCO) ? 'Abonado' : '-'),
                'Saída Final': item.saidaFinal ? formatarHora(item.saidaFinal) :
                    (item.totaisDia.abonos?.some(a => a.tipoAbonado === TIPOS_REGISTRO.SAIDA) ? 'Abonado' : '-'),
                'Horas Trabalhadas': formatarMinutosParaHora(item.totaisDia.horasTrabalhadas),
                'Horas Extras': formatarMinutosParaHora(item.totaisDia.horasExtras),
                'Atrasos': formatarMinutosParaHora(item.totaisDia.atrasoEntrada + item.totaisDia.atrasoVoltaAlmoco),
                'Situação': item.totaisDia.observacoes,
                'Abonos': item.totaisDia.abonos?.map(a => `${a.tipoAbonado}: ${a.justificativa}`).join('; ') || ''
            }));

            // Dados consolidados
            const dadosConsolidados = Object.keys(totaisPorUsuario).map(usuario => ({
                Usuário: usuario,
                'ID Login': totaisPorUsuario[usuario].idLogin || '',
                Jornada: totaisPorUsuario[usuario].jornada,
                Departamento: totaisPorUsuario[usuario].departamento,
                'Total Horas Extras': formatarMinutosParaHora(totaisPorUsuario[usuario].horasExtras),
                'Total Atrasos': formatarMinutosParaHora(totaisPorUsuario[usuario].atrasos),
                'Dias Trabalhados': totaisPorUsuario[usuario].diasTrabalhados,
                'Dias Abonados': totaisPorUsuario[usuario].diasAbonados,
                'Faltas': totaisPorUsuario[usuario].faltas
            }));

            // Criar workbook
            const wb = XLSX.utils.book_new();
            const wsDetalhado = XLSX.utils.json_to_sheet(dadosDetalhados);
            const wsConsolidado = XLSX.utils.json_to_sheet(dadosConsolidados);

            XLSX.utils.book_append_sheet(wb, wsDetalhado, 'Detalhado');
            XLSX.utils.book_append_sheet(wb, wsConsolidado, 'Consolidado');

            // Salvar arquivo
            XLSX.writeFile(wb, `Relatorio_Pontos_${new Date().toISOString().split('T')[0]}.xlsx`);
        } catch (error) {
            console.error('Erro ao exportar Excel:', error);
        }
    }

    const filtrarUsuarios = (usuariosUnicos) => {
        if (!filtros.busca) return usuariosUnicos;
        const busca = filtros.busca.toLowerCase();
        return usuariosUnicos.filter(usuario =>
            usuario.toLowerCase().includes(busca) ||
            (totaisPorUsuario[usuario]?.idLogin && totaisPorUsuario[usuario].idLogin.toString().toLowerCase().includes(busca))
        );
    };

    // Paginação
    const usuariosUnicos = [...new Set(dadosAgrupados.map(item => item.usuario))];
    const usuariosFiltrados = filtrarUsuarios(usuariosUnicos);
    const totalPaginas = Math.ceil(usuariosFiltrados.length / itensPorPagina);
    const usuariosPaginados = usuariosFiltrados.slice(
        (paginaAtual - 1) * itensPorPagina,
        paginaAtual * itensPorPagina
    );

    const dadosPorUsuario = usuariosPaginados.map(usuario => ({
        usuario,
        registros: dadosAgrupados
            .filter(item => item.usuario === usuario)
            .sort((a, b) => new Date(a.data) - new Date(b.data)),
        totais: totaisPorUsuario[usuario] || {}
    }));

    return (
        <Layout titulo="Relatório de Ponto Avançado">
            <div className="relatorio-container">
                <FiltrosAvancados
                    filtros={filtros}
                    setFiltros={setFiltros}
                    departamentos={departamentos}
                    handleAplicarFiltros={handleAplicarFiltros}
                    handleLimparFiltros={handleLimparFiltros}
                />

                <div className="botoes-relatorio mb-4">
                    <Row>
                        <Col md={6}>
                            <Form.Control
                                type="text"
                                placeholder="Buscar por nome ou ID..."
                                value={filtros.busca}
                                onChange={(e) => setFiltros({...filtros, busca: e.target.value})}
                            />
                        </Col>
                        <Col md={6} className="d-flex justify-content-end">
                            <Button onClick={exportarExcel} disabled={carregando} className="me-2">
                                Exportar Excel
                            </Button>
                            <Button
                                variant="info"
                                onClick={() => setJornadaAtiva(jornadaAtiva === '12/36' ? '6/1' : '12/36')}
                                title="Alternar entre jornadas"
                            >
                                Jornada: {jornadaAtiva}
                            </Button>
                        </Col>
                    </Row>
                </div>

                {carregando ? (
                    <div className="text-center my-5">
                        <Spinner animation="border" role="status">
                            <span className="visually-hidden">Carregando...</span>
                        </Spinner>
                        <p>Carregando dados...</p>
                    </div>
                ) : dadosAgrupados.length === 0 ? (
                    <p className="text-center my-5">Nenhum dado encontrado.</p>
                ) : (
                    <>
                        <GraficosAnaliticos dados={dadosPorUsuario} />

                        <div className="relatorio-usuarios">
                            {dadosPorUsuario.map((usuarioData, idx) => (
                                <div key={idx} className="usuario-container mb-5 shadow-sm">
                                    <div className="cabecalho-usuario p-3 bg-primary text-white rounded-top">
                                        <div className="d-flex justify-content-between align-items-center">
                                            <h3 className="mb-0">{usuarioData.usuario} (ID: {usuarioData.totais.idLogin || 'N/A'})</h3>
                                            <div>
                                                <button
                                                    onClick={() => prepararImpressao(usuarioData.usuario)}
                                                    className="btn btn-light me-2"
                                                >
                                                    Imprimir Relatório
                                                </button>
                                                <Badge bg="light" text="dark" className="fs-6">
                                                    {usuarioData.totais.jornada || '12/36'}
                                                </Badge>
                                            </div>
                                        </div>
                                        <div className="info-usuario mt-2">
                                            <span className="badge bg-light text-dark me-2">
                                                Departamento: {usuarioData.totais.departamento || 'Não informado'}
                                            </span>
                                        </div>
                                    </div>

                                    <div className="totais-usuario p-3 bg-light">
                                        <div className="row">
                                            <div className="col-md-2">
                                                <div className="card bg-success text-white">
                                                    <div className="card-body p-2 text-center">
                                                        <h6 className="card-title mb-0">Horas Extras</h6>
                                                        <p className="card-text mb-0">{formatarMinutosParaHora(usuarioData.totais.horasExtras || 0)}</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-md-2">
                                                <div className="card bg-warning text-dark">
                                                    <div className="card-body p-2 text-center">
                                                        <h6 className="card-title mb-0">Atrasos</h6>
                                                        <p className="card-text mb-0">{formatarMinutosParaHora(usuarioData.totais.atrasos || 0)}</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-md-2">
                                                <div className="card bg-info text-white">
                                                    <div className="card-body p-2 text-center">
                                                        <h6 className="card-title mb-0">Dias Trab.</h6>
                                                        <p className="card-text mb-0">{usuarioData.totais.diasTrabalhados || 0}</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-md-2">
                                                <div className="card bg-secondary text-white">
                                                    <div className="card-body p-2 text-center">
                                                        <h6 className="card-title mb-0">Dias Abon.</h6>
                                                        <p className="card-text mb-0">{usuarioData.totais.diasAbonados || 0}</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-md-2">
                                                <div className="card bg-danger text-white">
                                                    <div className="card-body p-2 text-center">
                                                        <h6 className="card-title mb-0">Faltas</h6>
                                                        <p className="card-text mb-0">{usuarioData.totais.faltas || 0}</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-md-2">
                                                <div className="card bg-primary text-white">
                                                    <div className="card-body p-2 text-center">
                                                        <h6 className="card-title mb-0">Total Dias</h6>
                                                        <p className="card-text mb-0">{(usuarioData.totais.diasTrabalhados || 0) + (usuarioData.totais.diasAbonados || 0) + (usuarioData.totais.faltas || 0)}</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="table-responsive">
                                        <table className="table table-striped table-hover tabela-relatorio mb-0">
                                            <thead className="table-dark">
                                            <tr>
                                                <th>Data</th>
                                                <th>Entrada</th>
                                                <th>Saída Almoço</th>
                                                <th>Volta Almoço</th>
                                                <th>Saída Final</th>
                                                <th>Horas</th>
                                                <th>Extras</th>
                                                <th>Atrasos</th>
                                                <th>Situação</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            {usuarioData.registros.map((item, idx) => {
                                                const classeLinha = item.totaisDia.observacoes.includes('Falta') ? 'table-danger' :
                                                    item.totaisDia.observacoes.includes('abonado') ? 'table-info' : '';
                                                return (
                                                    <tr key={idx} className={classeLinha}>
                                                        <td>{formatarDataBR(item.data)}</td>
                                                        <td>{item.entrada ? formatarHora(item.entrada) :
                                                            (item.totaisDia.abonos?.some(a => a.tipoAbonado === TIPOS_REGISTRO.ENTRADA) ? 'Abonado' : '-')}</td>
                                                        <td>{item.saidaAlmoco ? formatarHora(item.saidaAlmoco) :
                                                            (item.totaisDia.abonos?.some(a => a.tipoAbonado === TIPOS_REGISTRO.SAIDA_ALMOCO) ? 'Abonado' : '-')}</td>
                                                        <td>{item.voltaAlmoco ? formatarHora(item.voltaAlmoco) :
                                                            (item.totaisDia.abonos?.some(a => a.tipoAbonado === TIPOS_REGISTRO.VOLTA_ALMOCO) ? 'Abonado' : '-')}</td>
                                                        <td>{item.saidaFinal ? formatarHora(item.saidaFinal) :
                                                            (item.totaisDia.abonos?.some(a => a.tipoAbonado === TIPOS_REGISTRO.SAIDA) ? 'Abonado' : '-')}</td>
                                                        <td>{formatarMinutosParaHora(item.totaisDia.horasTrabalhadas)}</td>
                                                        <td>{formatarMinutosParaHora(item.totaisDia.horasExtras)}</td>
                                                        <td>
                                                            {item.totaisDia.atrasoEntrada > 0 && `E:${formatarMinutosParaHora(item.totaisDia.atrasoEntrada)}`}
                                                            {item.totaisDia.atrasoVoltaAlmoco > 0 && ` V:${formatarMinutosParaHora(item.totaisDia.atrasoVoltaAlmoco)}`}
                                                            {(item.totaisDia.atrasoEntrada === 0 && item.totaisDia.atrasoVoltaAlmoco === 0) && '-'}
                                                        </td>
                                                        <td>{item.totaisDia.observacoes}</td>
                                                    </tr>
                                                );
                                            })}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            ))}
                        </div>

                        {totalPaginas > 1 && (
                            <Paginacao
                                paginaAtual={paginaAtual}
                                totalPaginas={totalPaginas}
                                mudarPagina={setPaginaAtual}
                            />
                        )}
                    </>
                )}
            </div>

            <Modal show={showImpressao} onHide={() => setShowImpressao(false)} size="xl" centered>
                <Modal.Body className="p-0">
                    {empresa && usuarioImpressao && (
                        <RelatorioImpressao
                            empresa={empresa}
                            usuario={usuarioImpressao}
                            registros={dadosAgrupados
                                .filter(item => item.usuario === usuarioImpressao.nome)
                                .sort((a, b) => new Date(a.data) - new Date(b.data))}
                            periodo={periodoImpressao}
                            onClose={() => setShowImpressao(false)}
                            jornadaConfig={JORNADAS[usuarioImpressao.jornada] || JORNADAS['12/36']}
                        />
                    )}
                </Modal.Body>
            </Modal>
        </Layout>
    );
}